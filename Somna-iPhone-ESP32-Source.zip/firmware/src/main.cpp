#include <Arduino.h>
#include <Wire.h>
#include <esp_timer.h>
#include "Seeed_LDC1612.h"

#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

#define SERVICE_UUID \
  "b37a0001-9c4b-4f53-a3c1-5d8e64010000"

#define CHARACTERISTIC_UUID \
  "b37a0002-9c4b-4f53-a3c1-5d8e64010000"

// 0 = chest; 1 = abdomen.
// This identifies the band to the phone,
// independently of the sensor input channel.
constexpr uint8_t BAND_ROLE = 0;

constexpr uint8_t SENSOR_ADDRESS = 0x2B;
constexpr uint32_t SAMPLE_INTERVAL_MS = 100;

LDC1612 sensor;

BLECharacteristic* dataCharacteristic = nullptr;

volatile bool phoneConnected = false;
volatile bool restartAdvertising = false;

bool sensorReady = false;
uint32_t sampleSequence = 0;
unsigned long lastSample = 0;
unsigned long lastErrorPrint = 0;

class ConnectionCallbacks : public BLEServerCallbacks {
 public:
  void onConnect(BLEServer* server) override {
    phoneConnected = true;
  }

  void onDisconnect(BLEServer* server) override {
    phoneConnected = false;
    restartAdvertising = true;
  }
};

bool sensorPresent() {
  Wire.beginTransmission(SENSOR_ADDRESS);
  return Wire.endTransmission() == 0;
}

void writeLittleEndian(
    uint8_t* destination,
    uint64_t value,
    size_t length
) {
  for (size_t i = 0; i < length; i++) {
    destination[i] =
        static_cast<uint8_t>((value >> (8 * i)) & 0xFF);
  }
}

void setup() {
  Serial.begin(115200);
  delay(2000);

  BLEDevice::init(
      BAND_ROLE == 0 ? "chest_test" : "abdomen_test"
  );

  BLEServer* server = BLEDevice::createServer();
  server->setCallbacks(new ConnectionCallbacks());

  BLEService* service =
      server->createService(SERVICE_UUID);

  dataCharacteristic = service->createCharacteristic(
      CHARACTERISTIC_UUID,
      BLECharacteristic::PROPERTY_READ |
      BLECharacteristic::PROPERTY_NOTIFY
  );

  dataCharacteristic->addDescriptor(new BLE2902());
  service->start();

  BLEAdvertising* advertising =
      BLEDevice::getAdvertising();

  advertising->addServiceUUID(SERVICE_UUID);
  advertising->setScanResponse(true);
  advertising->start();

  Serial.println("Bluetooth advertising started.");

  // XIAO ESP32-C3 wiring:
  // White/SDA  -> D4/GPIO6
  // Yellow/SCL -> D5/GPIO7
  // Red/VCC    -> 3V3
  // Black/GND  -> GND
  Wire.begin(6, 7);
  Wire.setClock(100000);
  Wire.setTimeOut(100);

  if (!sensorPresent()) {
    Serial.println("ERROR: LDC1612 not found at 0x2B.");
    Serial.println("Disconnect power and check sensor wiring.");
    return;
  }

  sensor.init();

  // The library's single_channel_config ignores its channel
  // argument. Use its multi-channel function to enable CH1.
  // "mutiple" is the actual spelling in the library.
  if (sensor.LDC1612_mutiple_channel_config()) {
    Serial.println("ERROR: Sensor configuration failed.");
    return;
  }

  sensorReady = true;

  Serial.println("Sensor configured for both channels.");
  Serial.println("Reading CH1 and sending binary-v1 packets.");
  Serial.println("Test CH1 with the supplied Coil-1 first.");
}

void loop() {
  if (restartAdvertising) {
    restartAdvertising = false;
    delay(200);
    BLEDevice::startAdvertising();
    Serial.println("Bluetooth advertising restarted.");
  }

  const unsigned long now = millis();

  if (now - lastSample < SAMPLE_INTERVAL_MS) {
    delay(1);
    return;
  }

  lastSample = now;

  if (!sensorReady) {
    if (now - lastErrorPrint >= 2000) {
      lastErrorPrint = now;
      Serial.println(
          "Sensor not initialized. Check startup messages."
      );
    }
    return;
  }

  if (!sensorPresent()) {
    if (now - lastErrorPrint >= 2000) {
      lastErrorPrint = now;
      Serial.println("ERROR: Sensor disconnected.");
    }
    return;
  }

  uint32_t raw = 0;
  sensor.get_channel_result(CHANNEL_1, &raw);

  if (raw == 0 || raw >= 0x0FFFFFFFUL) {
    // Limit our invalid-reading message to once per second.
    if (now - lastErrorPrint >= 1000) {
      lastErrorPrint = now;
      Serial.print("Invalid CH1 sensor reading: ");
      Serial.println(raw);
    }
    return;
  }

  const uint64_t timestamp =
      static_cast<uint64_t>(esp_timer_get_time()) / 1000ULL;

  const uint32_t sequence = sampleSequence++;

  // Exact format expected by your phone's BandSample.decode.
  uint8_t packet[20] = {};

  packet[0] = 83;  // S
  packet[1] = 77;  // M
  packet[2] = 1;   // Protocol version

  // Bit 0: band role.
  // Bit 1: simulated flag, left OFF for real readings.
  packet[3] = BAND_ROLE;

  writeLittleEndian(packet + 4, timestamp, 8);
  writeLittleEndian(packet + 12, sequence, 4);
  writeLittleEndian(packet + 16, raw, 4);

  dataCharacteristic->setValue(packet, sizeof(packet));

  if (phoneConnected) {
    dataCharacteristic->notify();
  }

  Serial.print("CH1=");
  Serial.print(raw);
  Serial.print(", seq=");
  Serial.print(sequence);
  Serial.print(", phone=");
  Serial.println(
      phoneConnected ? "connected" : "disconnected"
  );
}
