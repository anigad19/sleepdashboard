import Foundation
import Combine
import WebKit
import UIKit
import SwiftUI

/// Uploads only while the user enables sharing. Credentials remain in WebKit's
/// cookie store and in memory, and are sent only to this exact HTTPS origin.
final class CloudUploader: NSObject, ObservableObject, URLSessionTaskDelegate {
    static let site = URL(string: "https://somna-live-monitor.cheekydog1024.chatgpt.site")!
    @Published var sharing = false
    @Published var authenticated = false
    @Published var status = "Online sharing is off."
    @Published var uploaded: UInt64 = 0
    @Published var dropped: UInt64 = 0
    private var cookieHeader = ""
    private var stream: String
    private var pending: [BandSample] = []
    private struct Envelope: Encodable {
        let stream: String
        let batch: String
        let samples: [BandSample]
    }
    private var retryBatch: Envelope?
    private var task: URLSessionDataTask?
    private var busy = false
    private var nextSend = Date.distantPast
    private var failures = 0
    private var generation = 0
    private var timer: Timer?
    private lazy var session: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.httpShouldSetCookies = false
        config.timeoutIntervalForRequest = 15
        config.timeoutIntervalForResource = 20
        return URLSession(configuration: config, delegate: self, delegateQueue: nil)
    }()

    override init() {
        let saved = UserDefaults.standard.string(forKey: "somna.cloud.stream")
        stream = saved ?? UUID().uuidString
        super.init()
        UserDefaults.standard.set(stream, forKey: "somna.cloud.stream")
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in self?.flush() }
    }

    func refreshLogin() {
        WKWebsiteDataStore.default().httpCookieStore.getAllCookies { [weak self] cookies in
            guard let self = self, let host = Self.site.host else { return }
            let matching = cookies.filter { cookie in
                let domain = cookie.domain.hasPrefix(".") ? String(cookie.domain.dropFirst()) : cookie.domain
                return (host == domain || host.hasSuffix("." + domain)) &&
                       cookie.path == "/" && (cookie.expiresDate == nil || cookie.expiresDate! > Date())
            }
            self.cookieHeader = HTTPCookie.requestHeaderFields(with: matching)["Cookie"] ?? ""
            var request = URLRequest(url: Self.site.appendingPathComponent("api/status"))
            request.setValue(self.cookieHeader, forHTTPHeaderField: "Cookie")
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            self.session.dataTask(with: request) { [weak self] data, response, _ in
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    let json = data.flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: Any] }
                    self.authenticated = (response as? HTTPURLResponse)?.statusCode == 200 && json?["ok"] as? Bool == true
                    self.status = self.authenticated ? "Signed in. Enable Share live online." : "Tap Online setup and sign in to your account."
                    if !self.authenticated { self.stop() }
                }
            }.resume()
        }
    }

    func start() {
        guard authenticated else { status = "Sign in using Online setup first."; return }
        generation += 1; sharing = true; failures = 0; nextSend = .distantPast
        status = "Sharing enabled. Waiting for Bluetooth samples…"
    }

    func stop() {
        generation += 1; sharing = false; task?.cancel(); task = nil; busy = false
        pending.removeAll(); retryBatch = nil
        status = authenticated ? "Online sharing is off." : "Sign in using Online setup first."
    }

    func enqueue(_ sample: BandSample) {
        guard sharing else { return }
        pending.append(sample)
        if pending.count > 2400 {
            let count = pending.count - 2400; dropped += UInt64(count)
            pending.removeFirst(count)
        }
        // CoreBluetooth callbacks can arrive when a UI timer is suspended.
        if Date() >= nextSend { flush() }
    }

    private func flush() {
        guard sharing, !busy, Date() >= nextSend else { return }
        let envelope: Envelope
        if let retry = retryBatch {
            envelope = retry
        } else {
            guard !pending.isEmpty else { return }
            let count = min(pending.count, 80)
            envelope = Envelope(stream: stream, batch: UUID().uuidString, samples: Array(pending.prefix(count)))
            pending.removeFirst(count)
        }
        guard let body = try? JSONEncoder().encode(envelope) else { return }
        busy = true
        let operation = generation
        var request = URLRequest(url: Self.site.appendingPathComponent("api/ingest"))
        request.httpMethod = "POST"; request.httpBody = body
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("iphone-v1", forHTTPHeaderField: "X-Somna-Client")
        request.setValue(cookieHeader, forHTTPHeaderField: "Cookie")
        task = session.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                guard let self = self, self.generation == operation else { return }
                self.busy = false; self.task = nil
                let code = (response as? HTTPURLResponse)?.statusCode ?? 0
                let json = data.flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: Any] }
                if error == nil && code == 200 && json?["ok"] as? Bool == true {
                    self.retryBatch = nil; self.failures = 0
                    self.uploaded += UInt64(envelope.samples.count)
                    self.nextSend = Date().addingTimeInterval(1)
                    self.status = "Live online · \(self.uploaded) samples uploaded" + (self.dropped > 0 ? " · \(self.dropped) upload samples dropped" : "")
                } else if code == 401 || code == 403 || code == 302 || code == 200 {
                    self.authenticated = false; self.stop()
                    self.status = "Login expired. Open Online setup and sign in again."
                } else {
                    self.retryBatch = envelope; self.failures += 1
                    let delay = min(30.0, pow(2.0, Double(min(self.failures, 5))))
                    self.nextSend = Date().addingTimeInterval(delay)
                    self.status = "Internet upload paused. Retrying in \(Int(delay))s. Local recording continues."
                }
            }
        }
        task?.resume()
    }

    // Never forward private-site session cookies through an HTTP redirect.
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }
}

struct CloudSignInView: UIViewRepresentable {
    let uploader: CloudUploader
    func makeCoordinator() -> Coordinator { Coordinator(uploader: uploader) }
    func makeUIView(context: Context) -> WKWebView {
        let web = WKWebView()
        web.navigationDelegate = context.coordinator
        web.uiDelegate = context.coordinator
        web.load(URLRequest(url: CloudUploader.site.appendingPathComponent("phone-connect")))
        return web
    }
    func updateUIView(_ view: WKWebView, context: Context) {}
    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        let uploader: CloudUploader
        init(uploader: CloudUploader) { self.uploader = uploader }
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            if webView.url?.host == CloudUploader.site.host { uploader.refreshLogin() }
        }
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            decisionHandler(navigationAction.request.url?.scheme == "https" ? .allow : .cancel)
        }
        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                     for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            if navigationAction.targetFrame == nil { webView.load(navigationAction.request) }
            return nil
        }
    }
}
