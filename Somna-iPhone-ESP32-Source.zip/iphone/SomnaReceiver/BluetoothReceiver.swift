import Foundation
import CoreBluetooth
import Combine

final class BluetoothReceiver: NSObject, ObservableObject, CBCentralManagerDelegate, CBPeripheralDelegate {
    let cloud = CloudUploader()
    static let service = CBUUID(string: "b37a0001-9c4b-4f53-a3c1-5d8e64010000")
    static let characteristic = CBUUID(string: "b37a0002-9c4b-4f53-a3c1-5d8e64010000")
    @Published var status = "Turn on Bluetooth, then tap Connect bands."
    @Published var recording = false
    @Published var count: UInt64 = 0
    @Published var latestFile: URL?
    var onRecordingStopped: (() -> Void)?
    var onSamples: (([BandSample]) -> Void)?
    var onConnection: ((String, Bool) -> Void)?
    private var central: CBCentralManager!
    private var peers: [UUID: CBPeripheral] = [:]
    private var roles: [UUID: String] = [:]
    private var offsets: [UUID: Double] = [:]
    private var lastSequence: [UUID: UInt32] = [:]
    private var lastDeviceTime: [UUID: UInt64] = [:]
    private var retry: [UUID: Int] = [:]
    private var enabled = false
    private var pending: [BandSample] = []
    private var flushTimer: Timer?
    private var log: FileHandle?
    private var logRows = 0
    private var lastSync = Date()

    override init() {
        super.init()
        central = CBCentralManager(delegate: self, queue: .main)
        flushTimer = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { [weak self] _ in
            guard let self = self, !self.pending.isEmpty else { return }
            let batch = self.pending; self.pending.removeAll(keepingCapacity: true)
            self.onSamples?(batch)
        }
        // A crash/interruption leaves an ordinary readable CSV, rather than a lost in-memory session.
        if let directory = try? recordingDirectory(),
           let files = try? FileManager.default.contentsOfDirectory(at: directory,
                            includingPropertiesForKeys: [.contentModificationDateKey]) {
            latestFile = files.filter { $0.pathExtension == "csv" }.sorted {
                $0.lastPathComponent > $1.lastPathComponent
            }.first
        }
    }

    private func recordingDirectory() throws -> URL {
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Recordings", isDirectory: true)
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    func start() {
        enabled = true
        guard central.state == .poweredOn else {
            status = "Bluetooth is unavailable. Allow Bluetooth access in Settings."; return
        }
        for peripheral in peers.values where peripheral.state == .disconnected {
            central.connect(peripheral, options: nil)
        }
        central.scanForPeripherals(withServices: [Self.service], options: nil)
        status = "Looking for Somna bands… Keep your ESP32 powered."
    }

    func disconnect() {
        enabled = false; central.stopScan()
        for peripheral in peers.values { central.cancelPeripheralConnection(peripheral) }
        for role in roles.values { onConnection?(role, false) }
        peers.removeAll(); roles.removeAll(); offsets.removeAll()
        lastSequence.removeAll(); lastDeviceTime.removeAll(); retry.removeAll()
        status = "Bands disconnected."
    }

    func beginRecording() {
        guard !recording else { return }
        do {
            let stamp = ISO8601DateFormatter().string(from: Date()).replacingOccurrences(of: ":", with: "-")
            let url = try recordingDirectory().appendingPathComponent("Somna-\(stamp)-\(UUID().uuidString.prefix(6)).csv")
            try Data("source,band,received_iso,device_time_ms,sequence,raw_value\n".utf8)
                .write(to: url, options: .atomic)
            // Allows continued writes after the screen locks following first device unlock.
            try FileManager.default.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication],
                                                   ofItemAtPath: url.path)
            let handle = try FileHandle(forWritingTo: url)
            try handle.seekToEnd()
            log = handle; latestFile = url; logRows = 0; recording = true
            status = "Recording received samples to your iPhone."
        } catch { status = "Could not create recording: \(error.localizedDescription)" }
    }

    func endRecording() {
        guard recording else { return }
        recording = false
        do { try log?.synchronize(); try log?.close(); status = "Recording saved · \(logRows) samples." }
        catch { status = "Recording close error: \(error.localizedDescription)" }
        log = nil
        onRecordingStopped?()
    }

    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn {
            status = "Bluetooth ready. Tap Connect bands."
            if enabled { start() }
        } else {
            status = central.state == .unauthorized ? "Allow Bluetooth for Somna in iPhone Settings." : "Bluetooth is off or unavailable."
            for role in roles.values { onConnection?(role, false) }
        }
    }

    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral,
                        advertisementData: [String: Any], rssi RSSI: NSNumber) {
        guard enabled, peers[peripheral.identifier] == nil, peers.count < 2 else { return }
        peers[peripheral.identifier] = peripheral
        peripheral.delegate = self
        status = "Connecting to \(peripheral.name ?? "Somna")…"
        central.connect(peripheral, options: nil)
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        offsets.removeValue(forKey: peripheral.identifier)
        lastSequence.removeValue(forKey: peripheral.identifier)
        lastDeviceTime.removeValue(forKey: peripheral.identifier)
        retry[peripheral.identifier] = 0
        peripheral.discoverServices([Self.service])
    }

    private func retryConnection(_ peripheral: CBPeripheral) {
        let id = peripheral.identifier
        if let role = roles.removeValue(forKey: id) { onConnection?(role, false) }
        offsets.removeValue(forKey: id); lastSequence.removeValue(forKey: id)
        lastDeviceTime.removeValue(forKey: id)
        guard enabled, peers[id] != nil else { return }
        let attempts = (retry[id] ?? 0) + 1; retry[id] = attempts
        let delay = min(30.0, pow(2.0, Double(min(attempts, 5))))
        status = "Band disconnected. Retrying in \(Int(delay)) seconds…"
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
            guard let self = self, self.enabled, self.peers[id] != nil,
                  self.central.state == .poweredOn else { return }
            self.central.connect(peripheral, options: nil)
        }
    }

    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        retryConnection(peripheral)
    }
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        retryConnection(peripheral)
    }
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        guard error == nil, let services = peripheral.services else {
            status = "Service discovery failed."; central.cancelPeripheralConnection(peripheral); return
        }
        for service in services where service.uuid == Self.service {
            peripheral.discoverCharacteristics([Self.characteristic], for: service)
        }
    }
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard error == nil else { status = "Characteristic discovery failed."; return }
        for characteristic in service.characteristics ?? [] where characteristic.uuid == Self.characteristic {
            peripheral.setNotifyValue(true, for: characteristic)
        }
    }
    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        status = error == nil && characteristic.isNotifying
            ? "Connected. Waiting for a valid band reading…"
            : "Could not enable live notifications: \(error?.localizedDescription ?? "unknown error")"
    }
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        guard error == nil, let data = characteristic.value,
              var sample = BandSample.decode(data) else {
            status = "Unreadable packet. Upload the new binary-v1 firmware."; return
        }
        let id = peripheral.identifier
        if roles.contains(where: { $0.key != id && $0.value == sample.band }) {
            status = "Two nodes claim the same band. Upload chest and abdomen targets separately."
            peers.removeValue(forKey: id); central.cancelPeripheralConnection(peripheral); return
        }
        if let previous = lastDeviceTime[id], sample.t < previous {
            offsets.removeValue(forKey: id); lastSequence.removeValue(forKey: id)
            onConnection?(sample.band, false)
        }
        if let previous = lastSequence[id], sample.seq <= previous,
           previous < UInt32.max - 1000 { return }
        let arrival = Date().timeIntervalSince1970 * 1000
        if offsets[id] == nil { offsets[id] = arrival - Double(sample.t) }
        sample.received = offsets[id]! + Double(sample.t)
        lastSequence[id] = sample.seq; lastDeviceTime[id] = sample.t
        let newRole = roles[id] == nil; roles[id] = sample.band
        if newRole { onConnection?(sample.band, true) }
        count += 1
        cloud.enqueue(sample)
        // The native file is authoritative. JS receives a bounded live queue only.
        if recording, let log = log {
            let formatter = ISO8601DateFormatter()
            formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            let iso = formatter.string(from: Date(timeIntervalSince1970: sample.received / 1000))
            let line = "\(sample.simulated ? "simulated" : "hardware"),\(sample.band),\(iso),\(sample.t),\(sample.seq),\(sample.value)\n"
            do {
                try log.write(contentsOf: Data(line.utf8)); logRows += 1
                if Date().timeIntervalSince(lastSync) >= 1 { try log.synchronize(); lastSync = Date() }
            } catch {
                recording = false; try? log.close(); self.log = nil
                status = "Recording stopped: \(error.localizedDescription)"
            }
        }
        pending.append(sample)
        if pending.count > 2400 { pending.removeFirst(pending.count - 2400) }
        if count % 20 == 0 {
            status = "\(sample.simulated ? "TEST DATA · " : "")\(roles.count)/2 bands · \(count) samples received"
        }
    }
}
