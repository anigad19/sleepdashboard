import SwiftUI
import WebKit

@main
struct SomnaReceiverApp: App {
    @StateObject private var receiver = BluetoothReceiver()
    var body: some Scene {
        WindowGroup { ReceiverScreen(receiver: receiver).preferredColorScheme(.dark) }
    }
}

struct ShareFile: Identifiable { let id = UUID(); let url: URL }
final class ReceiverUIState: ObservableObject {
    @Published var sharing: ShareFile?
    @Published var showingCloud = false
}
struct ReceiverScreen: View {
    @ObservedObject var receiver: BluetoothReceiver
    @StateObject private var ui = ReceiverUIState()
    var body: some View {
        VStack(spacing: 0) {
            VStack(alignment: .leading, spacing: 8) {
                Text("Somna · iPhone receiver").font(.headline)
                Text(receiver.status).font(.caption).foregroundColor(.secondary)
                HStack {
                    Button("Connect bands") { receiver.start() }
                    Button(receiver.recording ? "Stop & save" : "Record CSV") {
                        if receiver.recording { receiver.endRecording() } else { receiver.beginRecording() }
                    }.tint(receiver.recording ? .orange : .mint)
                    Button("Share CSV") {
                        if receiver.recording { receiver.endRecording() }
                        if let url = receiver.latestFile { ui.sharing = ShareFile(url: url) }
                    }.disabled(receiver.latestFile == nil)
                }.font(.caption).buttonStyle(.bordered)
                HStack {
                    Text("20 Hz per band · local collection").font(.caption2).foregroundColor(.secondary)
                    Spacer()
                    Button("Disconnect") { receiver.disconnect() }.font(.caption2)
                }
            }.padding(12).background(Color(red: 0.075, green: 0.11, blue: 0.13))
            CloudControls(uploader: receiver.cloud, showingLogin: $ui.showingCloud)
            DashboardView(receiver: receiver) { ui.sharing = ShareFile(url: $0) }
        }
        .sheet(isPresented: $ui.showingCloud, onDismiss: { receiver.cloud.refreshLogin() }) {
            NavigationStack { CloudSignInView(uploader: receiver.cloud)
                .navigationTitle("Somna online setup")
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { ui.showingCloud = false } } }
            }
        }
        .sheet(item: $ui.sharing) { ShareSheet(url: $0.url) }
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [url], applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}

struct DashboardView: UIViewRepresentable {
    let receiver: BluetoothReceiver
    let onShare: (URL) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(receiver: receiver, onShare: onShare) }
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        let bridge = "window.SomnaNative={post:function(message){window.webkit.messageHandlers.somna.postMessage(message);}};"
        config.userContentController.addUserScript(WKUserScript(source: bridge, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        config.userContentController.add(context.coordinator, name: "somna")
        let web = WKWebView(frame: .zero, configuration: config)
        web.isOpaque = false
        web.backgroundColor = UIColor(red: 0.063, green: 0.09, blue: 0.106, alpha: 1)
        web.navigationDelegate = context.coordinator
        context.coordinator.web = web
        if let file = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "Dashboard") {
            web.loadFileURL(file, allowingReadAccessTo: file.deletingLastPathComponent())
        } else {
            web.loadHTMLString("<h2>Dashboard resources missing</h2><p>Add the Dashboard folder as a blue folder resource in Xcode.</p>", baseURL: nil)
        }
        return web
    }
    func updateUIView(_ web: WKWebView, context: Context) {}
    final class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate {
        weak var web: WKWebView?
        let receiver: BluetoothReceiver
        let onShare: (URL) -> Void
        var ready = false
        init(receiver: BluetoothReceiver, onShare: @escaping (URL) -> Void) {
            self.receiver = receiver; self.onShare = onShare
            super.init()
            receiver.onRecordingStopped = { [weak self] in self?.send("recordStopped", ["stopped": true]) }
            receiver.onSamples = { [weak self] batch in self?.send("samples", batch) }
            receiver.onConnection = { [weak self] band, connected in
                self?.send("connection", ["band": band, "connected": connected] as [String: Any])
            }
        }
        func send<T: Encodable>(_ kind: String, _ payload: T) {
            guard ready, let data = try? JSONEncoder().encode(payload), let json = String(data: data, encoding: .utf8) else { return }
            web?.evaluateJavaScript("window.SomnaReceive?.('\(kind)',\(json));", completionHandler: nil)
        }
        func send(_ kind: String, _ payload: [String: Any]) {
            guard ready, let data = try? JSONSerialization.data(withJSONObject: payload),
                  let json = String(data: data, encoding: .utf8) else { return }
            web?.evaluateJavaScript("window.SomnaReceive?.('\(kind)',\(json));", completionHandler: nil)
        }
        func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
            guard message.frameInfo.isMainFrame, message.frameInfo.request.url?.isFileURL == true,
                  let body = message.body as? [String: Any], let command = body["command"] as? String else { return }
            switch command {
            case "ready": ready = true
            case "scan": receiver.start()
            case "disconnect": receiver.disconnect()
            case "recordStart": receiver.beginRecording()
            case "recordStop": receiver.endRecording()
            case "download":
                guard let text = body["text"] as? String, let name = body["name"] as? String,
                      text.utf8.count < 20_000_000 else { return }
                let url = FileManager.default.temporaryDirectory.appendingPathComponent((name as NSString).lastPathComponent)
                do { try Data(text.utf8).write(to: url, options: .atomic); onShare(url) }
                catch { receiver.status = "Export failed: \(error.localizedDescription)" }
            default: break
            }
        }
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            // Only the bundled dashboard receives the native Bluetooth bridge.
            decisionHandler(navigationAction.request.url?.isFileURL == true ? .allow : .cancel)
        }
    }
}

struct CloudControls: View {
    @ObservedObject var uploader: CloudUploader
    @Binding var showingLogin: Bool
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack {
                Button("Online setup") { showingLogin = true }
                Spacer()
                Toggle("Share live online", isOn: Binding(get: { uploader.sharing }, set: { value in
                    if value { uploader.start() } else { uploader.stop() }
                })).font(.caption).fixedSize()
            }
            Text(uploader.status).font(.caption2).foregroundColor(.secondary)
        }.padding(.horizontal, 12).padding(.vertical, 8)
    }
}
