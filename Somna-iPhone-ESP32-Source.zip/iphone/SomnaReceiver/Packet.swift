import Foundation

struct BandSample: Codable {
    let band: String
    let t: UInt64
    let seq: UInt32
    let value: UInt32
    let simulated: Bool
    var received: Double = 0

    // 20-byte little-endian wire protocol, independent of alignment.
    static func decode(_ data: Data) -> BandSample? {
        let b = Array(data)
        guard b.count == 20, b[0] == 83, b[1] == 77,
              b[2] == 1, b[3] & 0xFC == 0 else { return nil }
        func integer(_ offset: Int, _ length: Int) -> UInt64 {
            (0..<length).reduce(0) { $0 | UInt64(b[offset + $1]) << ($1 * 8) }
        }
        let raw = integer(16, 4)
        guard raw > 0, raw < 0x0FFFFFFF else { return nil }
        return BandSample(band: b[3] & 1 == 0 ? "chest" : "abdomen",
                          t: integer(4, 8), seq: UInt32(integer(12, 4)),
                          value: UInt32(raw), simulated: b[3] & 2 != 0)
    }
}
