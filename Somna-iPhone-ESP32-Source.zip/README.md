# Somna sleep monitoring

Wireless respiratory-band prototype: ESP32 firmware, iPhone receiver, and web dashboard.

## Projects

- `firmware/`: current PlatformIO ESP32-C3 sensor and BLE project, copied from `Somna-Sensor-Test` on November 1, 2026. Open this folder in VS Code with PlatformIO.
- `iphone/`: iPhone receiver with local dashboard, CSV recording, and internet uploading. Open `iphone/SomnaReceiver.xcodeproj` in Xcode and select your signing team and physical iPhone.
- Existing dashboard files remain in their original locations.

## Firmware configuration

The target is `seeed_xiao_esp32c3`, with Arduino and the Seeed LDC1612 library. Serial monitor: 115200 baud. The current reader uses CH1 at a target 100 ms interval. `BAND_ROLE` in `firmware/src/main.cpp` identifies chest (`0`) or abdomen (`1`) independently of the sensor input channel. BLE sends the 20-byte binary-v1 packet decoded by `iphone/SomnaReceiver/Packet.swift`.

## iPhone internet setup

The cloud endpoint is configured in `iphone/SomnaReceiver/CloudUploader.swift`. Use Online setup in the app to sign in and enable Share live online. Hosting and server-side code for that endpoint are separate from the existing static dashboard in this repository.

## Snapshot status

Source files were copied without changing app or sensor behavior. Sensor values and BLE connection have been observed during project development; response to band stretching remains unresolved. This upload does not validate the physical sensor or overnight monitoring. No fresh device build or hardware test was run for this source backup.

Build output, Xcode user state, local recordings, and signing credentials are excluded. This is a research prototype.
